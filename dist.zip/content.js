"use strict";
(() => {
  // src/shared/preferences.ts
  var DEFAULT_PREFERENCES = {
    enabledByHost: {},
    theme: "system",
    density: "comfortable"
  };
  function normalizePreferences(value) {
    return {
      enabledByHost: value?.enabledByHost ?? {},
      theme: value?.theme ?? DEFAULT_PREFERENCES.theme,
      density: value?.density ?? DEFAULT_PREFERENCES.density
    };
  }
  function isEnabledForHost(preferences2, hostname) {
    return preferences2.enabledByHost[hostname] ?? true;
  }
  async function readPreferences() {
    const stored = await chrome.storage.sync.get(DEFAULT_PREFERENCES);
    return normalizePreferences(stored);
  }

  // src/shared/routes.ts
  function isSupportedBoardsRoute(pathname) {
    const normalized = pathname.toLowerCase().replace(/\/+$/, "");
    return normalized === "_boards" || normalized.endsWith("/_boards") || normalized.includes("/_boards/");
  }

  // src/content.ts
  var root = document.documentElement;
  var preferences;
  var cardSelector = ".kanban-card, .work-item-card, .board-card";
  var accentSourceSelector = [
    ".work-item-type-icon",
    ".work-item-type",
    ".work-item-color",
    ".card-color",
    ".type-icon",
    ".wit-icon",
    '[class*="accent"]',
    '[class*="type"]',
    "[style]"
  ].join(", ");
  function isAccentColor(color) {
    const channels = color.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*[,/]\s*([\d.]+))?/i);
    if (!channels || channels[4] !== void 0 && Number(channels[4]) === 0) return false;
    const rgb = channels.slice(1, 4).map(Number);
    return Math.max(...rgb) - Math.min(...rgb) >= 12;
  }
  function colorFromComputedStyle(element) {
    const style = getComputedStyle(element);
    const candidates = [style.borderLeftColor, style.borderInlineStartColor, style.outlineColor, style.backgroundColor];
    for (let index = 0; index < style.length; index += 1) {
      const property = style[index];
      if (property.startsWith("--") && /(accent|color|type)/i.test(property)) candidates.push(style.getPropertyValue(property));
    }
    return candidates.find(isAccentColor);
  }
  function detectCardAccent(card) {
    return colorFromComputedStyle(card) ?? Array.from(card.querySelectorAll(accentSourceSelector)).map(colorFromComputedStyle).find(Boolean);
  }
  function annotateCards(active = root.hasAttribute("data-abm-active")) {
    const cards = document.querySelectorAll(cardSelector);
    cards.forEach((card) => {
      if (!active) {
        card.removeAttribute("data-abm-card-accent");
        card.style.removeProperty("--abm-card-accent");
        return;
      }
      const accent = detectCardAccent(card);
      const cardAccent = accent ?? "var(--abm-border)";
      if (card.style.getPropertyValue("--abm-card-accent") !== cardAccent) {
        card.style.setProperty("--abm-card-accent", cardAccent);
      }
      card.toggleAttribute("data-abm-card-accent", Boolean(accent));
    });
  }
  var annotationQueued = false;
  function queueCardAnnotation() {
    if (annotationQueued) return;
    annotationQueued = true;
    requestAnimationFrame(() => {
      annotationQueued = false;
      annotateCards();
    });
  }
  function applyModernizer() {
    const active = Boolean(
      preferences && isSupportedBoardsRoute(location.pathname) && isEnabledForHost(preferences, location.hostname)
    );
    if (active) annotateCards(true);
    root.toggleAttribute("data-abm-active", active);
    if (!active) annotateCards();
    if (!preferences) return;
    root.dataset.abmTheme = preferences.theme;
    root.dataset.abmDensity = preferences.density;
  }
  async function refreshPreferences() {
    preferences = await readPreferences();
    applyModernizer();
  }
  function observeRoutes() {
    const dispatchLocationChange = () => {
      window.dispatchEvent(new Event("abm:locationchange"));
    };
    for (const method of ["pushState", "replaceState"]) {
      const original = history[method];
      history[method] = function(...args) {
        const result = original.apply(this, args);
        dispatchLocationChange();
        return result;
      };
    }
    window.addEventListener("popstate", dispatchLocationChange);
    window.addEventListener("abm:locationchange", applyModernizer);
  }
  function observeCards() {
    const observer = new MutationObserver(queueCardAnnotation);
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
  observeRoutes();
  observeCards();
  void refreshPreferences();
  chrome.storage.onChanged.addListener((_changes, areaName) => {
    if (areaName === "sync") void refreshPreferences();
  });
})();
//# sourceMappingURL=content.js.map
