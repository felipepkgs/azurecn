"use strict";
(() => {
  // src/shared/preferences.ts
  var DEFAULT_PREFERENCES = {
    enabledByHost: {},
    theme: "system",
    density: "comfortable"
  };
  function normalizePreferences(value) {
    return {
      enabledByHost: value?.enabledByHost ?? {},
      theme: value?.theme ?? DEFAULT_PREFERENCES.theme,
      density: value?.density ?? DEFAULT_PREFERENCES.density
    };
  }
  function isEnabledForHost(preferences2, hostname) {
    return preferences2.enabledByHost[hostname] ?? true;
  }
  async function readPreferences() {
    const stored = await chrome.storage.sync.get(DEFAULT_PREFERENCES);
    return normalizePreferences(stored);
  }

  // src/shared/routes.ts
  function isSupportedBoardsRoute(pathname) {
    const normalized = pathname.toLowerCase().replace(/\/+$/, "");
    return normalized === "_boards" || normalized.endsWith("/_boards") || normalized.includes("/_boards/");
  }

  // src/content.ts
  var root = document.documentElement;
  var preferences;
  function applyModernizer() {
    const active = Boolean(
      preferences && isSupportedBoardsRoute(location.pathname) && isEnabledForHost(preferences, location.hostname)
    );
    root.toggleAttribute("data-abm-active", active);
    if (!preferences) return;
    root.dataset.abmTheme = preferences.theme;
    root.dataset.abmDensity = preferences.density;
  }
  async function refreshPreferences() {
    preferences = await readPreferences();
    applyModernizer();
  }
  function observeRoutes() {
    const dispatchLocationChange = () => {
      window.dispatchEvent(new Event("abm:locationchange"));
    };
    for (const method of ["pushState", "replaceState"]) {
      const original = history[method];
      history[method] = function(...args) {
        const result = original.apply(this, args);
        dispatchLocationChange();
        return result;
      };
    }
    window.addEventListener("popstate", dispatchLocationChange);
    window.addEventListener("abm:locationchange", applyModernizer);
  }
  observeRoutes();
  void refreshPreferences();
  chrome.storage.onChanged.addListener((_changes, areaName) => {
    if (areaName === "sync") void refreshPreferences();
  });
})();
//# sourceMappingURL=content.js.map
