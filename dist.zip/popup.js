"use strict";
(() => {
  // src/shared/preferences.ts
  var DEFAULT_PREFERENCES = {
    enabledByHost: {},
    theme: "system",
    density: "comfortable"
  };
  function normalizePreferences(value) {
    return {
      enabledByHost: value?.enabledByHost ?? {},
      theme: value?.theme ?? DEFAULT_PREFERENCES.theme,
      density: value?.density ?? DEFAULT_PREFERENCES.density
    };
  }
  async function readPreferences() {
    const stored = await chrome.storage.sync.get(DEFAULT_PREFERENCES);
    return normalizePreferences(stored);
  }
  async function savePreferences(preferences2) {
    await chrome.storage.sync.set(preferences2);
  }

  // src/popup.ts
  var enabled = document.querySelector("#enabled");
  var siteName = document.querySelector("#site-name");
  var hostname = "dev.azure.com";
  var preferences;
  function render() {
    enabled.checked = preferences.enabledByHost[hostname] ?? true;
    document.querySelectorAll("[data-theme]").forEach((button) => {
      button.dataset.selected = String(button.dataset.theme === preferences.theme);
    });
    document.querySelectorAll("[data-density]").forEach((button) => {
      button.dataset.selected = String(button.dataset.density === preferences.density);
    });
  }
  async function persist() {
    await savePreferences(preferences);
    render();
  }
  async function initialize() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    hostname = tab.url ? new URL(tab.url).hostname : hostname;
    siteName.textContent = hostname === "dev.azure.com" ? "dev.azure.com" : hostname;
    preferences = await readPreferences();
    render();
  }
  enabled.addEventListener("change", () => {
    preferences.enabledByHost[hostname] = enabled.checked;
    void persist();
  });
  document.querySelectorAll("[data-theme]").forEach((button) => {
    button.addEventListener("click", () => {
      preferences.theme = button.dataset.theme;
      void persist();
    });
  });
  document.querySelectorAll("[data-density]").forEach((button) => {
    button.addEventListener("click", () => {
      preferences.density = button.dataset.density;
      void persist();
    });
  });
  void initialize();
})();
//# sourceMappingURL=popup.js.map
